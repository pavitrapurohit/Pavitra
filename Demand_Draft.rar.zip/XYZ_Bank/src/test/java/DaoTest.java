
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


public class DaoTest {
	
  @Mock
  private IDemandDraftDAO dDao;
  private IDemandDraftService dService;

@Before
public void setup() {
	
	MockitoAnnotations.initMocks(this);
	dService=new DemandDraftService(dDao);

}
@Test
public void test_acc_with_proper_format() {
	DemandDraft demandDraft=new DemandDraft();
	demandDraft.setCustomer_Name("Pavitra");
	demandDraft.setIn_favour_of("Shrey");
    demandDraft.setPhone_number("9123456789");
    demandDraft.setDate_of_transaction(LocalDate.of(1996, 10, 10));
    demandDraft.setDd_amount(5000);
    demandDraft.setDd_commission(10);
    demandDraft.setDd_description("noo");
    
    Mockito.when(dDao.addDemandDraftDetails(demandDraft)).thenReturn(1);
    dService.addDemandDraftDetails(demandDraft);
    Mockito.verify(dDao).addDemandDraftDetails(demandDraft);
}
	

}
